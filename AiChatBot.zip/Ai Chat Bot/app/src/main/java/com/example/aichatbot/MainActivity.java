package com.example.aichatbot;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.aichatbot.adapter.ChatAdapter;
import com.example.aichatbot.model.ChatMessage;
import com.example.aichatbot.service.GeminiService;

public class MainActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private EditText messageInput;
    private Button sendButton;
    private ChatAdapter adapter;
    private GeminiService geminiService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        recyclerView = findViewById(R.id.recyclerView);
        messageInput = findViewById(R.id.messageInput);
        sendButton = findViewById(R.id.sendButton);

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ChatAdapter();
        recyclerView.setAdapter(adapter);

        // Initialize Gemini service
        geminiService = new GeminiService();

        // Add a welcome message
        addBotMessage("Hello! I'm your AI assistant. How can I help you today?");

        // Set up the send button
        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendMessage();
            }
        });
    }

    private void sendMessage() {
        String message = messageInput.getText().toString().trim();
        if (TextUtils.isEmpty(message)) {
            return;
        }

        // Display user message
        addUserMessage(message);
        messageInput.setText("");

        // Show "thinking" indicator
        addBotMessage("Thinking...");
        final int botThinkingPosition = adapter.getItemCount() - 1;

        // Send request to Gemini API
        geminiService.generateResponse(message, new GeminiService.ResponseCallback() {
            @Override
            public void onResponse(final String response) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        // Remove "thinking" message
                        adapter.removeMessage(botThinkingPosition);
                        // Add actual response
                        addBotMessage(response);
                    }
                });
            }

            @Override
            public void onError(final Throwable throwable) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        // Remove "thinking" message
                        adapter.removeMessage(botThinkingPosition);
                        // Add error message
                        addBotMessage("Sorry, I couldn't process your request. Please try again.");
                        Toast.makeText(MainActivity.this,
                                "Error: " + throwable.getMessage(),
                                Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private void addUserMessage(String message) {
        adapter.addMessage(new ChatMessage(message, ChatMessage.TYPE_USER));
        scrollToBottom();
    }

    private void addBotMessage(String message) {
        adapter.addMessage(new ChatMessage(message, ChatMessage.TYPE_BOT));
        scrollToBottom();
    }

    private void scrollToBottom() {
        recyclerView.smoothScrollToPosition(adapter.getItemCount() - 1);
    }
}