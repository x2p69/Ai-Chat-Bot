package com.example.aichatbot.service;

import android.content.Context;

import com.google.ai.client.generativeai.GenerativeModel;
import com.google.ai.client.generativeai.type.Content;
import com.google.ai.client.generativeai.type.GenerationConfig;
import com.google.ai.client.generativeai.type.GenerateContentResponse;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.io.IOException;

import kotlinx.coroutines.flow.Flow;

public class GeminiService {
    private static final String API_KEY = "AIzaSyAN80XInQCHOl08D7v3SqJmSetGo6MpDn8"; // Your API key
    private static final String MODEL_NAME = "gemini-pro";
    private final GenerativeModel model;
    private final Executor executor = Executors.newSingleThreadExecutor();

    public GeminiService() {
        model = new GenerativeModel(MODEL_NAME, API_KEY);
    }

    public interface ResponseCallback {
        void onResponse(String response);
        void onError(Throwable throwable);
    }

    public void generateResponse(String prompt, ResponseCallback callback) {
        executor.execute(() -> {
            try {
                // Create content with the user's prompt
                Content content = Content.builder()
                        .addText(prompt)
                        .build();

                // Generate the response
                GenerateContentResponse response = model.generateContent(content);

                // Get the text from the response
                String responseText = response.getText();

                // Call the callback with the response
                callback.onResponse(responseText);
            } catch (Exception e) {
                // Handle any errors
                callback.onError(e);
            }
        });
    }
}